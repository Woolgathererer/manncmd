#!/bin/bash
sudo_version=$(sudo -V | awk -F" " '{print $3}')
#echo $sudo_version
sudo_num1=$(echo $sudo_version | awk -F" " '{print $1}')
#echo $sudo_num1
sudo_num2=$(echo $sudo_num1 | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
#echo $sudo_num2
if [[ $sudo_num2 -lt 1008028 ]]; then # if sudo version is lower than 1008028
    echo "May be vulnerable to CVE-2019-14287"
else
    echo "not vulnerable to CVE-2019-14287"
fi

