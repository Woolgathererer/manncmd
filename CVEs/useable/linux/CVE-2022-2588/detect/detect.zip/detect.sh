#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
if [[ $kernel_version -ge 3017000 && $kernel_version -lt 5019000 ]]; then # if kernel version beteen 3.17 and 5.19
    echo "May be vulnerable to CVE-2022-2588"
else
    echo "not vulnerable to CVE-2021-2588" 
fi