./exp
su user << EOD
user
id
EOD