sudo apt install linux-headers-5.8.0-48-generic linux-image-5.8.0-48-generic linux-modules-5.8.0-48-generic linux-modules-extra-5.8.0-48-generic

sudo sed -i 's/GRUB_DEFAULT=0/GRUB_DEFAULT="Advanced options for Ubuntu>Ubuntu, with Linux 5.8.0-48-genetic"/g' /etc/default/grub

sudo update-grub

sudo reboot