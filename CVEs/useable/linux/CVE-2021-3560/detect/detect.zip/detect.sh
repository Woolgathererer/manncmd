#!/bin/bash
polkitVersion=$(systemctl status polkit.service | grep version | cut -d " " -f 9)
if [[ "$(apt list --installed 2>/dev/null | grep polkit | grep -c 0.105-26)" -ge 1 ]]; then
    echo "May be vulnerable to CVE-2021-3560"
else
    echo "not vulnerable to CVE-2021-3560"
fi