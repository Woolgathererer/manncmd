#!/bin/bash
ssl_version=$(openssl version | awk -F" " '{print $2}')
#echo $ssl_version
if [[ $ssl_version < "1.1.1l" ]]; then # if OpenSSL version is lower than 1.1.1l
    echo "May be vulnerable to CVE-2021-3711"
else
    echo "not vulnerable to CVE-2021-3711"
fi
