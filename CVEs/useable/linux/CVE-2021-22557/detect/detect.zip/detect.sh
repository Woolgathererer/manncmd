#!/bin/bash
export PATH="$HOME/.local/bin:$PATH"
if [ `command -v slo-generator` ]; then
slo_version=$(slo-generator | awk -F"v" '{ printf("%s\n",$2); }')
# echo $slo_version
slo_num=$(echo $slo_version | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
# echo $slo_num
if [[ $slo_num -lt 2000001 ]]; then
  echo "May be vulnerable to CVE-2021-22557"
fi
fi