pip3 install slo-generator==2.0.0

export PATH="$HOME/.local/bin:$PATH"
