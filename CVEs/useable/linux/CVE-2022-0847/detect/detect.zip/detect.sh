#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3,$4); }')
if [[ $kernel_version -ge 5008000 && $kernel_version -lt 5017000 ]]; then # if kernel version beteen 5.8 and 5.17
    echo "May be vulnerable to CVE-2022-0847"
else
  echo "not vulnerable to CVE-2021-0847" 
fi