./exp << EOD

whoami

id

exit

EOD
