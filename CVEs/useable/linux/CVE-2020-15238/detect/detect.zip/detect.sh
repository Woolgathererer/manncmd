#!/bin/bash
blueman_version=$(dpkg -s blueman | grep "Version")
#echo $blueman_version
blueman_num1=$(echo $blueman_version | awk -F" " '{print $2}')
#echo $blueman_num1
blueman_num2=$(echo $blueman_num1 | awk -F"-" '{print $1}')
blueman_num3=$(echo $blueman_num2 | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
#echo $sudo_num2
#echo $blueman_num3
if [[ $blueman_num3 -lt 2001004 ]]; then # if kernel version beteen 5.7 and 5.12.4
    echo "May be vulnerable to CVE-2020-15238"
else
    echo "not vulnerable to CVE-2020-15238"
fi
