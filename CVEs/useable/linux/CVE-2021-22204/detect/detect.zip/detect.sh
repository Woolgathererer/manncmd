#!/bin/bash

if [ `command -v exiftool` ]; then
  exiftool=$(exiftool -ver | awk -F. '{ printf("%d%03d\n", $1,$2); }')
  if [[ $exiftool -ge 7044 && $exiftool -lt 12024 ]]; then
    echo "May be vulnerable to CVE-2021-22204"
  else
    echo "not vulnerable to CVE-2021-22204" 
  fi
else
    echo "not vulnerable to CVE-2021-22204" 
fi
