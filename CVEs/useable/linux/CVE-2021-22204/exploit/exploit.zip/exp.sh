python3 test.py -c id

exiftool image.jpg