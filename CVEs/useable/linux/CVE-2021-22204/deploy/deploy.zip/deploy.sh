cd exiftool*

make install
