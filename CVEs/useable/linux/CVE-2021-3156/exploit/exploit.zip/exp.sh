./exp 2 << EOD

whoami

exit

EOD
