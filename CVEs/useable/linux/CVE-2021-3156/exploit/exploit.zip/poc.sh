sudoedit -s /
