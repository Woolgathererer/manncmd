#!/bin/bash
sudo_version=$(sudo -V | awk -F" " '{print $3}')
#echo $sudo_version
sudo_num1=$(echo $sudo_version | awk -F" " '{print $1}')
#echo $sudo_num1
sudo_num2=$(echo $sudo_num1 | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
#echo $sudo_num2
if [[ $sudo_num2 -ge 1008002 && $sudo_num2 -lt 1008031 ]]; then # if kernel version beteen 5.7 and 5.12.4
    echo "May be vulnerable to CVE-2021-3156"
elif [[ $sudo_num2 -ge 1009000 && $sudo_num2 -lt 1009005 ]]; then # if kernel version beteen 5.7 and 5.12.4
    echo "May be vulnerable to CVE-2021-3156"
else
    echo "not vulnerable to CVE-2021-3156"
fi

