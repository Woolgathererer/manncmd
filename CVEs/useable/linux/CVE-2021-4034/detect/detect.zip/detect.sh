#!/bin/bash
if [ `command -v pkexec` ]; then
    fact1=$(stat -c '%a' $(which pkexec))
    if [ $fact1 == 4755 ]; then
        fact2=$(stat -c '%Y' $(which pkexec))
            if [ $fact2 -lt "1642035600" ]; then
                echo "May be vulnerable to CVE-2021-4034"
            else
                echo "not vulnerable to CVE-2021-4034" 
            fi
        else
            echo "not vulnerable to CVE-2021-4034" 
    fi
else
    echo "not vulnerable to CVE-2021-4034" 
fi