./exp << EOD

whoami

exit

EOD
