#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
if [[ $kernel_version -ge 4010000 && $kernel_version -lt 4014103 ]]; then # if kernel version beteen 4.15 and 4.19.2
    echo "May be vulnerable to CVE-2019-8912"
elif [[ $kernel_version -ge 4019000 && $kernel_version -lt 4019025 ]]; then
    echo "May be vulnerable to CVE-2019-8912"
elif [[ $kernel_version -ge 4020000 && $kernel_version -lt 4020012 ]]; then
    echo "May be vulnerable to CVE-2019-8912"
else
    echo "not vulnerable to CVE-2019-8912"
fi