python3 exp.py << EOD

whoami

id

exit

EOD
