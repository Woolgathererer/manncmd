#!/bin/bash
snap_version=$(snap version | grep "snapd")
# echo $snap_version
snap_num1=$(echo $snap_version | awk -F" " '{print $2}')
# echo $snap_num1
snap_num2=$(echo $snap_num1 | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
# echo $snap_num2
if [[ $snap_num2 -lt 2037001 ]]; then # if snap version lower than 2.37.1
    echo "May be vulnerable to CVE-2019-7304"
else
    echo "not vulnerable to CVE-2019-7304"
fi