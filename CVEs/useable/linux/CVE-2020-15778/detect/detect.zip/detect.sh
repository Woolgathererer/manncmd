#!/bin/bash
ssh_version=$(dpkg --list | grep openssh-server)
# echo $ssh_version
ssh_num1=$(echo $ssh_version | awk -F" " '{print $3}')
# echo $ssh_num1
ssh_num2=$(echo $ssh_num1 | awk -F":" '{print $2}' | awk -F"-" '{print $1}')
# echo $ssh_num2
if [[ $ssh_num2 == "8.3p1" ]]; then # if ssh_server version is 8.3p1
    echo "May be vulnerable to CVE-2020-15778"
else
    echo "not vulnerable to CVE-2020-15778"
fi
