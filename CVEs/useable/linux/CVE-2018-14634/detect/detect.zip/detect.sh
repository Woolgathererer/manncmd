#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
if [[ $kernel_version -ge 2006000 && $kernel_version -lt 2006039 ]]; then # if kernel version beteen 4.15 and 4.19.2
    echo "May be vulnerable to CVE-2018-14634"
elif [[ $kernel_version -ge 3015000 && $kernel_version -lt 3010102 ]]; then
    echo "May be vulnerable to CVE-2018-14634"
elif [[ $kernel_version -ge 4014000 && $kernel_version -lt 4014054 ]]; then
    echo "May be vulnerable to CVE-2018-14634"
else
    echo "not vulnerable to CVE-2018-14634"
fi