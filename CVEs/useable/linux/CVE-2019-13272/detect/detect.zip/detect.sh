#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
#echo $kernel_version
if [[ $kernel_version -ge 4010000 && $kernel_version -lt 5001017 ]]; then # if kernel version beteen 4.10 and 5.1.17
    echo "May be vulnerable to CVE-2019-13272"
else
    echo "not vulnerable to CVE-2019-13272"
fi