./exp << EOD

whoami

id

EOD
