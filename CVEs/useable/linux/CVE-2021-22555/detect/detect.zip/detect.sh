#!/bin/bash
Linux_kernel=$(uname -r | awk -F"-" '{print $1}')
kernel_version=$(echo $Linux_kernel | awk -F. '{ printf("%d%03d%03d\n", $1,$2,$3); }')
if [[ $kernel_version -ge 2016009 && $kernel_version -lt 5009000 ]]; then # if kernel version beteen 2.16.9 and 5.9
    echo "May be vulnerable to CVE-2021-22555"
fi